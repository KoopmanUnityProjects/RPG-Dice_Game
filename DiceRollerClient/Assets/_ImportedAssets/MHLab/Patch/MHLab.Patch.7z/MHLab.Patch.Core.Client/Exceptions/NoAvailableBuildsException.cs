﻿using System;

namespace MHLab.Patch.Core.Client.Exceptions
{
    public class NoAvailableBuildsException : Exception
    {
    }
}
