﻿namespace MHLab.Patch.Core.Client.IO
{
    public interface IDownloadMetrics
    {
        int RunningThreads { get; }
    }
}
