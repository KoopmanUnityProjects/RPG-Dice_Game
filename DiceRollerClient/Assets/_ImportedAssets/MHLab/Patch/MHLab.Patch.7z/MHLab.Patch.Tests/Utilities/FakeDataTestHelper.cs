﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace MHLab.Patch.Tests.Utilities
{
    public static class FakeDataTestHelper
    {
        public static byte[] GetRandomByteArray(int length)
        {
            var random = new Random();
            var array = new byte[length];
            random.NextBytes(array);

            return array;
        }

        public static byte[] GetRandomByteArray()
        {
            var random = new Random();
            var array = new byte[random.Next(16, 256)];
            random.NextBytes(array);

            return array;
        }

        public static byte[] GetRandomByteArray(int minLength, int maxLength)
        {
            var random = new Random();
            var array = new byte[random.Next(minLength, maxLength)];
            random.NextBytes(array);

            return array;
        }

        public static int GetRandomInteger(int minLength = Int32.MinValue, int maxLength = Int32.MaxValue)
        {
            var random = new Random();
            return random.Next(minLength, maxLength);
        }

        private static readonly char[] AllowedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
        public static string GetRandomChars(int size)
        {
            byte[] data = new byte[4 * size];
            using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
            {
                crypto.GetBytes(data);
            }

            StringBuilder result = new StringBuilder(size);
            for (int i = 0; i < size; i++)
            {
                var rnd = BitConverter.ToUInt32(data, i * 4);
                var idx = rnd % AllowedChars.Length;

                result.Append(AllowedChars[idx]);
            }

            return result.ToString();
        }

        public static string GetGuidFilename()
        {
            return Guid.NewGuid().ToString();
        }
    }
}
