﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using MHLab.Patch.Core.IO;

namespace MHLab.Patch.Tests.Utilities
{
    public class InMemoryFileSystem : IFileSystem
    {
        private readonly Dictionary<string, MemoryStream>  _files;
        private readonly Dictionary<string, LocalFileInfo> _infos;

        public InMemoryFileSystem()
        {
            _files = new Dictionary<string, MemoryStream>();
            _infos = new Dictionary<string, LocalFileInfo>();
        }

        public void CreateDirectory(FilePath path)
        {
        }

        public FilePath GetDirectoryPath(FilePath path)
        {
            return (FilePath)PathsManager.GetDirectoryPath(path.FullPath);
        }

        public FilePath GetCurrentDirectory()
        {
            return (FilePath)FilesManager.SanitizePath(Directory.GetCurrentDirectory());
        }

        public bool IsDirectoryEmpty(FilePath path)
        {
            return !_files.Any(filePair => filePair.Key.Contains(path.FullPath));
        }

        public void DeleteDirectory(FilePath path)
        {
            var keysToRemove = _files.Where(filePair => filePair.Key.Contains(path.FullPath))
                                     .Select(filePair => filePair.Key)
                                     .ToArray();

            foreach (var key in keysToRemove)
            {
                _files.Remove(key);
                _infos.Remove(key);
            }
        }

        public FilePath GetApplicationDataPath(string folderName)
        {
            return (FilePath)FilesManager.SanitizePath(
                PathsManager.Combine(
                    PathsManager.GetSpecialPath(Environment.SpecialFolder.ApplicationData),
                    folderName
                )
            );
        }

        public FilePath CombinePaths(params string[] paths)
        {
            return (FilePath)PathsManager.Combine(paths);
        }

        public FilePath CombinePaths(string path1, string path2)
        {
            return (FilePath)PathsManager.Combine(path1, path2);
        }

        public FilePath CombineUri(params string[] uris)
        {
            return (FilePath)PathsManager.UriCombine(uris);
        }

        public FilePath SanitizePath(FilePath path)
        {
            return (FilePath)FilesManager.SanitizePath(path.FullPath);
        }

        public Stream CreateFile(FilePath path)
        {
            var basePath = path.BasePath;
            var fullPath = path.FullPath;

            var stream = new MemoryStream();
            var info = new LocalFileInfo()
            {
                Attributes  = FileAttributes.Normal,
                Size        = 0,
                LastWriting = DateTime.UtcNow,
                RelativePath = FilesManager.SanitizeToRelativePath(basePath, fullPath)
            };

            if (_files.ContainsKey(fullPath))
            {
                _files[fullPath] = stream;
                _infos[fullPath] = info;
            }
            else
            {
                _files.Add(fullPath, stream);
                _infos.Add(fullPath, info);
            }

            return stream;
        }

        public string GetFilename(FilePath path)
        {
            return PathsManager.GetFilename(path.FullPath);
        }

        public FilePath[] GetFilesList(FilePath path)
        {
            return _files.Where(filePair => filePair.Key.Contains(path.FullPath))
                         .Select(filePair => (FilePath)filePair.Key).ToArray();
        }

        public LocalFileInfo[] GetFilesInfo(FilePath path)
        {
            var files = GetFilesList(path);
            var infos = new LocalFileInfo[files.Length];

            for (int i = 0; i < files.Length; i++)
            {
                var currentPath = files[i];
                var stream      = _files[currentPath.FullPath];

                var localInfo = _infos[currentPath.FullPath];

                localInfo.Size         = stream.Length;
                localInfo.RelativePath = FilesManager.SanitizeToRelativePath(path.BasePath, currentPath.FullPath);

                infos[i] = localInfo;
            }

            return infos;
        }

        public void GetFilesInfo(FilePath                              path, out LocalFileInfo[] fileInfo,
                                 out Dictionary<string, LocalFileInfo> fileInfoMap)
        {
            var files    = GetFilesList(path);
            var infos    = new LocalFileInfo[files.Length];
            var infosMap = new Dictionary<string, LocalFileInfo>();

            for (int i = 0; i < files.Length; i++)
            {
                var currentPath = files[i];
                var stream      = _files[currentPath.FullPath];

                var localInfo = _infos[currentPath.FullPath];

                localInfo.Size         = stream.Length;
                localInfo.RelativePath = FilesManager.SanitizeToRelativePath(path.BasePath, currentPath.FullPath);

                infos[i] = localInfo;
                infosMap.Add(currentPath.FullPath, localInfo);
            }

            fileInfo    = infos;
            fileInfoMap = infosMap;
        }

        public LocalFileInfo GetFileInfo(FilePath path)
        {
            if (FileExists(path))
            {
                return _infos[path.FullPath];
            }

            throw new FileNotFoundException(path.FullPath);
        }

        public Stream GetFileStream(FilePath path, FileMode fileMode = FileMode.OpenOrCreate, FileAccess fileAccess = FileAccess.ReadWrite, FileShare fileShare = FileShare.ReadWrite)
        {
            var fullPath = path.FullPath;
            
            if (!FileExists(path))
            {
                CreateFile(path);
            }

            var stream = _files[fullPath];
            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }

        public string ReadAllTextFromFile(FilePath path)
        {
            if (FileExists(path))
            {
                var stream = _files[path.FullPath];
                return Encoding.UTF8.GetString(stream.ToArray());
            }

            throw new FileNotFoundException(path.FullPath);
        }

        public void WriteAllTextToFile(FilePath path, string content)
        {
            var fullPath = path.FullPath;
            
            if (!FileExists(path))
            {
                CreateFile(path);
            }

            var bytes = Encoding.UTF8.GetBytes(content);
            _files[fullPath]      = new MemoryStream(bytes);
            _infos[fullPath].Size = bytes.Length;
        }

        public byte[] ReadAllBytesFromFile(FilePath path)
        {
            if (FileExists(path))
            {
                var stream = _files[path.FullPath];
                return stream.ToArray();
            }

            throw new FileNotFoundException(path.FullPath);
        }

        public void WriteAllBytesToFile(FilePath path, byte[] content)
        {
            var fullPath = path.FullPath;
            
            if (!FileExists(path))
            {
                CreateFile(path);
            }
            
            _files[fullPath]      = new MemoryStream(content);
            _infos[fullPath].Size = content.Length;
        }

        public bool FileExists(FilePath path)
        {
            return _files.ContainsKey(path.FullPath);
        }

        public void CopyFile(FilePath sourcePath, FilePath destinationPath)
        {
            if (!FileExists(sourcePath)) throw new FileNotFoundException(sourcePath.FullPath);

            var stream = _files[sourcePath.FullPath];
            var info   = _infos[sourcePath.FullPath];

            var newStream = new MemoryStream();
            stream.CopyTo(newStream);
            newStream.Seek(0, SeekOrigin.Begin);
            var newInfo = new LocalFileInfo(info);

            if (_files.ContainsKey(destinationPath.FullPath))
            {
                _files[destinationPath.FullPath] = newStream;
                _infos[destinationPath.FullPath] = newInfo;
            }
            else
            {
                _files.Add(destinationPath.FullPath, newStream);
                _infos.Add(destinationPath.FullPath, newInfo);
            }
        }

        public void MoveFile(FilePath sourcePath, FilePath destinationPath)
        {
            if (!FileExists(sourcePath)) throw new FileNotFoundException(sourcePath.FullPath);

            var stream = _files[sourcePath.FullPath];
            var info   = _infos[sourcePath.FullPath];

            _files.Remove(sourcePath.FullPath);
            _infos.Remove(sourcePath.FullPath);

            if (_files.ContainsKey(destinationPath.FullPath))
            {
                _files[destinationPath.FullPath] = stream;
                _infos[destinationPath.FullPath] = info;
            }
            else
            {
                _files.Add(destinationPath.FullPath, stream);
                _infos.Add(destinationPath.FullPath, info);
            }
        }

        public void RenameFile(FilePath sourcePath, FilePath destinationPath)
        {
            if (!FileExists(sourcePath)) throw new FileNotFoundException(sourcePath.FullPath);

            var stream = _files[sourcePath.FullPath];
            var info   = _infos[sourcePath.FullPath];

            _files.Remove(sourcePath.FullPath);
            _infos.Remove(sourcePath.FullPath);

            if (_files.ContainsKey(destinationPath.FullPath))
            {
                _files[destinationPath.FullPath] = stream;
                _infos[destinationPath.FullPath] = info;
            }
            else
            {
                _files.Add(destinationPath.FullPath, stream);
                _infos.Add(destinationPath.FullPath, info);
            }
        }

        public bool IsFileLocked(FilePath path)
        {
            return false;
        }

        public void UnlockFile(FilePath path)
        {
            
        }

        public bool IsDirectoryWritable(FilePath path, bool throwOnFail = false)
        {
            return true;
        }

        public int DeleteMultipleFiles(FilePath path, string pattern)
        {
            var files = _files.Where(filePair => filePair.Key.Contains(path.FullPath));
            var count = 0;

            var regex = FilePatternRegex.Convert(pattern);
            
            foreach (var filePair in files)
            {
                var filePath = filePair.Key;

                if (regex.IsMatch(filePath))
                {
                    DeleteFile((FilePath)filePath);
                    count++;
                }
            }

            return count;
        }

        public int DeleteTemporaryDeletingFiles(FilePath folderPath)
        {
            return DeleteMultipleFiles(folderPath, "*.temp.delete_me");
        }

        public string GetTemporaryDeletingFileName(FilePath path)
        {
            return FilesManager.GetTemporaryDeletingFileName(path.FullPath);
        }

        public void DeleteFile(FilePath path)
        {
            if (_files.ContainsKey(path.FullPath))
            {
                _files.Remove(path.FullPath);
                _infos.Remove(path.FullPath);
            }
        }

        public long GetAvailableDiskSpace(FilePath path)
        {
            return FilesManager.GetAvailableDiskSpace(path.FullPath);
        }

        public void SetFileAttributes(FilePath path, FileAttributes attributes)
        {
            if (_infos.ContainsKey(path.FullPath))
            {
                _infos[path.FullPath].Attributes = attributes;
            }
        }

        public void SetLastWriteTime(FilePath path, DateTime date)
        {
            if (_infos.ContainsKey(path.FullPath))
            {
                _infos[path.FullPath].LastWriting = date;
            }
        }

        public void EnsureShortcutOnDesktop(FilePath path, string shortcutName)
        {
            var basePath     = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            var shortcutFile = Path.Combine(basePath, shortcutName + ".url");
            CreateFile(new FilePath(basePath, shortcutFile));
        }
    }
}