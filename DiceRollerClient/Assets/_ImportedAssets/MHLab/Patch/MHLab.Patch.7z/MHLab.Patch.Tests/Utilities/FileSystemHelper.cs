﻿using System;
using MHLab.Patch.Core.Admin;
using MHLab.Patch.Core.IO;
using MHLab.Patch.Core.Utilities.Asserts;

namespace MHLab.Patch.Tests.Utilities
{
    public static class FileSystemHelper
    {
        private static Random _random = new Random();
        
        public static void CreateNewGameInAppFolder(IFileSystem fileSystem, IAdminSettings settings)
        {
            const int filesAmountMin = 10;
            const int filesAmountMax = 50;
            const int fileMinSize    = 15;
            const int fileMaxSize    = 1024 * 1024 * 25;
            
            
            var filesAmount = _random.Next(filesAmountMin, filesAmountMax);
            var basePath    = settings.GetApplicationFolderPath();

            for (var i = 0; i < filesAmount; i++)
            {
                var filePath    = fileSystem.CombinePaths(basePath, FakeDataTestHelper.GetGuidFilename());
                var fileSize    = _random.Next(fileMinSize, fileMaxSize);
                var fileContent = FakeDataTestHelper.GetRandomByteArray(fileSize);

                var stream = fileSystem.CreateFile(new FilePath(basePath, filePath.FullPath));
                stream.Write(fileContent, 0, fileSize);
            }
            
            Assert.Check(filesAmount == fileSystem.GetFilesList((FilePath)basePath).Length);
        }
    }
}