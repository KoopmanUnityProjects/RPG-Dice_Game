﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MHLab.Patch.Core.Client.Advanced.IO;
using MHLab.Patch.Core.Client.IO;

namespace MHLab.Patch.Launcher.WinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            var dwld = new GDriveDownloader();
            dwld.Download(new List<DownloadEntry>(), null);
            InitializeComponent();
        }

    }
}
