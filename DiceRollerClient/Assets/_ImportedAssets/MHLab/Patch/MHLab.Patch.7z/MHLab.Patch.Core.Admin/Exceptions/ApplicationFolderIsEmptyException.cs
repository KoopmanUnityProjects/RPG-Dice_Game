﻿using System;

namespace MHLab.Patch.Core.Admin.Exceptions
{
    public class ApplicationFolderIsEmptyException : Exception
    {
    }
}
