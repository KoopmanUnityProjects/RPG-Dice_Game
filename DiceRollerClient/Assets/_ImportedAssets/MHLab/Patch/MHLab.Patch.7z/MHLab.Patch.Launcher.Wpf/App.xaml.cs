﻿using System.Windows;

namespace MHLab.Patch.Launcher.Wpf
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
